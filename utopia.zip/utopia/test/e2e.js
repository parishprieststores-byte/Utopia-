/* Two-client end-to-end test for Utopia */
const { io } = require('socket.io-client');

const URL = 'http://localhost:3000';
const ok = [];
const fail = [];
function check(name, cond) {
  (cond ? ok : fail).push(name);
  console.log(`${cond ? '✅' : '❌'} ${name}`);
}

async function main() {
  // login both users
  const loginA = await fetch(URL + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'alice', password: 'secret123' }) }).then(r => r.json());
  const loginB = await fetch(URL + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'bob', password: 'secret123' }) }).then(r => r.json());
  check('alice login', !!loginA.token);
  check('bob login', !!loginB.token);

  const roomsA = await fetch(URL + '/api/rooms', { headers: { Authorization: 'Bearer ' + loginA.token } }).then(r => r.json());
  const general = roomsA.rooms.find(r => r.name === 'general');
  check('general channel exists', !!general);

  // connect two sockets
  const sA = io(URL, { auth: { token: loginA.token } });
  const sB = io(URL, { auth: { token: loginB.token } });

  const presenceP = new Promise(res => sB.on('presence', res));
  const msgP = new Promise(res => sB.on('chat message', res));
  const typingP = new Promise(res => sB.on('typing', res));

  await new Promise(res => sA.on('connect', res));
  await new Promise(res => sB.on('connect', res));
  check('both sockets connected', true);

  const presence = await presenceP;
  check('presence broadcast received', Array.isArray(presence) && presence.length >= 2);

  sA.emit('typing', { roomId: general.id, userId: loginA.user.id });
  const typing = await typingP;
  check('typing indicator received by bob', typing && typing.username === 'alice');

  sA.emit('chat message', { roomId: general.id, text: 'Hello Utopia! 👋 from alice' });
  const msg = await msgP;
  check('realtime message delivered to bob', msg && msg.text === 'Hello Utopia! 👋 from alice' && msg.username === 'alice');

  // bob replies — wait specifically for a message authored by bob
  const msgP2 = new Promise(res => {
    const handler = (m) => {
      if (m.username === 'bob') { sA.off('chat message', handler); res(m); }
    };
    sA.on('chat message', handler);
  });
  sB.emit('chat message', { roomId: general.id, text: 'Hey alice, welcome to Utopia 🚀' });
  const msg2 = await msgP2;
  check('reply delivered to alice', msg2 && msg2.username === 'bob');

  // DM flow
  const dm = await fetch(URL + '/api/dm', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + loginA.token }, body: JSON.stringify({ username: 'bob' }) }).then(r => r.json());
  check('DM room created', dm.room && dm.room.is_dm === 1);

  const dmP = new Promise(res => sB.on('chat message', res));
  sA.emit('chat message', { roomId: dm.room.id, text: 'psst, private message' });
  const dmMsg = await dmP;
  check('DM delivered in realtime', dmMsg && dmMsg.text === 'psst, private message');

  sA.close(); sB.close();

  // history API check
  const hist = await fetch(URL + `/api/rooms/${general.id}/messages`, { headers: { Authorization: 'Bearer ' + loginA.token } }).then(r => r.json());
  check('history persisted (>=2 messages)', hist.messages && hist.messages.length >= 2);

  console.log(`\nRESULT: ${ok.length} passed, ${fail.length} failed`);
  process.exit(fail.length ? 1 : 0);
}

main().catch(e => { console.error('TEST ERROR', e); process.exit(1); });
