/* Utopia frontend */
const $ = (s) => document.querySelector(s);

let token = localStorage.getItem('utopia_token') || null;
let me = null;
let rooms = [];
let currentRoom = null;
let onlineIds = new Set();
let socket = null;
let lastTypingSent = 0;

const EMOJIS = ['😀','😂','😍','🤔','😎','😭','🔥','🎉','❤️','👍','👎','🙌','🙏','💯','🚀','✨','🍕','☕','😴','🤯','😅','😇','🥳','🤝','👀','💬','⚡','🌈','⭐','🍀','💡','🎯'];

/* ---------- helpers ---------- */
function api(path, opts = {}) {
  return fetch(path, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: 'Bearer ' + token } : {}),
      ...(opts.headers || {}),
    },
  }).then(async (r) => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || 'Request failed');
    return data;
  });
}

function initials(name) { return (name || '?').charAt(0); }
function fmtTime(iso) {
  return new Date(iso + (iso.endsWith('Z') ? '' : 'Z')).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function fmtDay(iso) {
  const d = new Date(iso + (iso.endsWith('Z') ? '' : 'Z'));
  const today = new Date();
  const yesterday = new Date(Date.now() - 86400000);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
}

/* ---------- auth UI ---------- */
let authMode = 'login';
function setAuthMode(mode) {
  authMode = mode;
  $('#tab-login').classList.toggle('active', mode === 'login');
  $('#tab-register').classList.toggle('active', mode === 'register');
  $('#auth-submit').textContent = mode === 'login' ? 'Sign in' : 'Create account';
}
$('#tab-login').onclick = () => setAuthMode('login');
$('#tab-register').onclick = () => setAuthMode('register');

$('#auth-form').onsubmit = async (e) => {
  e.preventDefault();
  $('#auth-error').textContent = '';
  try {
    const data = await api(`/api/${authMode}`, {
      method: 'POST',
      body: JSON.stringify({ username: $('#username').value, password: $('#password').value }),
    });
    token = data.token;
    localStorage.setItem('utopia_token', token);
    enterApp();
  } catch (err) {
    $('#auth-error').textContent = err.message;
  }
};

$('#logout-btn').onclick = () => {
  localStorage.removeItem('utopia_token');
  location.reload();
};

/* ---------- app init ---------- */
async function enterApp() {
  const data = await api('/api/me');
  me = data.user;
  $('#my-name').textContent = me.username;
  $('#my-avatar').textContent = initials(me.username);
  $('#auth-screen').classList.add('hidden');
  $('#app').classList.remove('hidden');

  connectSocket();
  await loadRooms();
  await loadUsers();
  if (rooms.length) selectRoom(rooms[0].id);
}

function connectSocket() {
  socket = io({ auth: { token } });

  socket.on('chat message', (msg) => {
    if (msg.room_id === currentRoom) addMessage(msg);
    setTyping(null);
  });

  socket.on('typing', ({ userId, username, roomId }) => {
    if (roomId === currentRoom && userId !== me.id) setTyping(username);
  });

  socket.on('presence', (ids) => {
    onlineIds = new Set(ids);
    renderPeople();
  });
}

function setTyping(username) {
  $('#typing-bar').textContent = username ? `${username} is typing…` : '';
  if (username) {
    clearTimeout(setTyping._t);
    setTyping._t = setTimeout(() => { $('#typing-bar').textContent = ''; }, 2500);
  }
}

/* ---------- rooms ---------- */
async function loadRooms() {
  const data = await api('/api/rooms');
  rooms = data.rooms;
  renderRooms();
}

function roomLabel(room) {
  if (room.is_dm) {
    const other = room.members.find((m) => m.id !== me.id);
    return other ? other.username : room.name;
  }
  return room.name;
}

function renderRooms() {
  const chEl = $('#channel-list');
  const dmEl = $('#dm-list');
  chEl.innerHTML = '';
  dmEl.innerHTML = '';
  for (const r of rooms) {
    const div = document.createElement('div');
    div.className = 'list-item' + (currentRoom === r.id ? ' active' : '');
    if (r.is_dm) {
      const other = r.members.find((m) => m.id !== me.id);
      div.innerHTML = `<span class="avatar">${initials(other && other.username)}</span> ${escapeHtml(roomLabel(r))}`;
      div.onclick = () => selectRoom(r.id);
      dmEl.appendChild(div);
    } else {
      div.innerHTML = `<span class="hash">#</span> ${escapeHtml(r.name)}`;
      div.onclick = () => selectRoom(r.id);
      chEl.appendChild(div);
    }
  }
}

$('#channel-form').onsubmit = async (e) => {
  e.preventDefault();
  const name = $('#channel-name').value.trim();
  if (!name) return;
  try {
    await api('/api/rooms', { method: 'POST', body: JSON.stringify({ name }) });
    $('#channel-name').value = '';
    await loadRooms();
  } catch (err) { alert(err.message); }
};

async function openDm(username) {
  try {
    await api('/api/dm', { method: 'POST', body: JSON.stringify({ username }) });
    await loadRooms();
    const dm = rooms.find((r) => r.is_dm && roomLabel(r) === username);
    if (dm) selectRoom(dm.id);
  } catch (err) { alert(err.message); }
}

/* ---------- people ---------- */
async function loadUsers() {
  const data = await api('/api/users');
  const sel = $('#dm-select');
  sel.innerHTML = '<option value="">Start a DM…</option>';
  for (const u of data.users) {
    const opt = document.createElement('option');
    opt.value = u.username;
    opt.textContent = u.username;
    sel.appendChild(opt);
  }
  renderPeople(data.users);
  window._allUsers = data.users;
}

function renderPeople(users) {
  const list = users || window._allUsers || [];
  $('#online-count').textContent = `${onlineIds.size} online`;
  const el = $('#people-list');
  el.innerHTML = '';
  for (const u of list) {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.innerHTML = `<span class="dot ${onlineIds.has(u.id) ? 'online' : ''}"></span> ${escapeHtml(u.username)}`;
    div.title = 'Open DM with ' + u.username;
    div.onclick = () => openDm(u.username);
    el.appendChild(div);
  }
}

$('#dm-select').onchange = (e) => { if (e.target.value) { openDm(e.target.value); e.target.value = ''; } };

/* ---------- messages ---------- */
async function selectRoom(id) {
  currentRoom = id;
  renderRooms();
  const room = rooms.find((r) => r.id === id);
  const label = roomLabel(room);
  $('#room-title').textContent = room.is_dm ? '@ ' + label : '# ' + label;
  const others = room.members.map((m) => m.username).filter((u) => u !== me.username);
  $('#room-sub').textContent = room.is_dm ? others.join(', ') : `${room.members.length} members`;
  $('#messages').innerHTML = '';
  const data = await api(`/api/rooms/${id}/messages`);
  if (!data.messages.length) {
    $('#messages').innerHTML = `<div class="empty"><div class="big">💬</div><div>No messages yet.<br>Say hello to start the conversation!</div></div>`;
  } else {
    data.messages.forEach(addMessage);
  }
  const box = $('#messages');
  box.scrollTop = box.scrollHeight;
  document.querySelector('.sidebar').classList.remove('open');
}

function addMessage(msg) {
  const box = $('#messages');
  const empty = box.querySelector('.empty');
  if (empty) empty.remove();

  const isMine = msg.user_id === me.id;
  const el = document.createElement('div');
  el.className = 'msg' + (isMine ? ' mine' : '');

  const last = box.querySelector('.msg:last-child');
  const newDay = !last || last.dataset.day !== fmtDay(msg.created_at);
  if (newDay) {
    const d = document.createElement('div');
    d.className = 'day-divider';
    d.textContent = fmtDay(msg.created_at);
    box.appendChild(d);
  }

  const showAuthor = !last || last.dataset.author !== msg.username || newDay;
  el.dataset.author = msg.username;
  el.dataset.day = fmtDay(msg.created_at);
  el.innerHTML = `
    ${showAuthor ? `<div class="avatar">${initials(msg.username)}</div>` : '<div style="width:30px"></div>'}
    <div class="msg-body">
      ${showAuthor ? `<div class="msg-head"><span class="msg-author">${escapeHtml(msg.username)}</span><span class="msg-time">${fmtTime(msg.created_at)}</span></div>` : ''}
      <div class="msg-text">${escapeHtml(msg.text)}</div>
    </div>`;
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

/* ---------- composer ---------- */
$('#msg-form').onsubmit = (e) => {
  e.preventDefault();
  const input = $('#msg-input');
  const text = input.value.trim();
  if (!text || !currentRoom || !socket) return;
  socket.emit('chat message', { roomId: currentRoom, text });
  input.value = '';
};

$('#msg-input').addEventListener('input', () => {
  if (!currentRoom || !socket) return;
  const now = Date.now();
  if (now - lastTypingSent > 1500) {
    lastTypingSent = now;
    socket.emit('typing', { roomId: currentRoom });
  }
});

/* emoji picker */
const picker = $('#emoji-picker');
for (const e of EMOJIS) {
  const b = document.createElement('button');
  b.type = 'button';
  b.textContent = e;
  b.onclick = () => { $('#msg-input').value += e; picker.classList.add('hidden'); $('#msg-input').focus(); };
  picker.appendChild(b);
}
$('#emoji-btn').onclick = (e) => { e.preventDefault(); picker.classList.toggle('hidden'); };
document.addEventListener('click', (e) => {
  if (!picker.contains(e.target) && e.target !== $('#emoji-btn')) picker.classList.add('hidden');
});

/* mobile sidebar */
$('#mobile-menu').onclick = () => document.querySelector('.sidebar').classList.toggle('open');

/* ---------- boot ---------- */
if (token) {
  enterApp().catch(() => {
    token = null;
    localStorage.removeItem('utopia_token');
  });
}
