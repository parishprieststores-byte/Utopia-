const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { signToken, requireAuth } = require('../auth/auth');

const router = express.Router();

// Ensure a channel exists by name and return its row
function ensureRoom(name) {
  let room = db.roomByName(name);
  if (!room) room = db.createRoom(name);
  return room;
}

router.post('/register', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
  const name = String(username).trim();
  if (!/^[a-zA-Z0-9_]{3,24}$/.test(name)) {
    return res.status(400).json({ error: 'Username must be 3-24 chars (letters, numbers, _)' });
  }
  if (String(password).length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
  if (db.getUserByName(name)) return res.status(409).json({ error: 'Username already taken' });

  const hash = bcrypt.hashSync(String(password), 10);
  const id = db.createUser(name, hash);

  // auto-join the default #general channel
  const general = ensureRoom('general');
  db.addMember(general.id, id);

  const token = signToken({ id, username: name });
  res.json({ token, user: { id, username: name } });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
  const user = db.getUserByName(String(username).trim());
  if (!user || !bcrypt.compareSync(String(password), user.password_hash)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  const token = signToken({ id: user.id, username: user.username });
  res.json({ token, user: { id: user.id, username: user.username } });
});

router.get('/me', requireAuth, (req, res) => {
  const user = db.getUserById(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user });
});

router.get('/users', requireAuth, (req, res) => {
  res.json({ users: db.allUsers().filter((u) => u.id !== req.user.id) });
});

router.get('/rooms', requireAuth, (req, res) => {
  const rooms = db.userRooms(req.user.id).map((r) => ({
    ...r,
    members: db.roomMembers(r.id),
  }));
  res.json({ rooms });
});

router.post('/rooms', requireAuth, (req, res) => {
  const { name } = req.body || {};
  const clean = String(name || '').trim().toLowerCase().replace(/\s+/g, '-');
  if (!/^[a-z0-9-]{2,24}$/.test(clean)) {
    return res.status(400).json({ error: 'Channel name must be 2-24 chars (a-z, 0-9, -)' });
  }
  if (db.roomByName(clean)) return res.status(409).json({ error: 'Channel already exists' });
  const room = db.createRoom(clean);
  db.addMember(room.id, req.user.id);
  res.json({ room: { ...room, members: db.roomMembers(room.id) } });
});

router.post('/dm', requireAuth, (req, res) => {
  const { username } = req.body || {};
  const other = db.getUserByName(String(username || '').trim());
  if (!other) return res.status(404).json({ error: 'User not found' });
  if (other.id === req.user.id) return res.status(400).json({ error: 'Cannot DM yourself' });
  const room = db.createDm(req.user.id, other.id);
  res.json({ room: { ...room, members: db.roomMembers(room.id) } });
});

router.get('/rooms/:id/messages', requireAuth, (req, res) => {
  const roomId = Number(req.params.id);
  if (!db.isMember(roomId, req.user.id)) return res.status(403).json({ error: 'Not a member of this room' });
  res.json({ messages: db.roomMessages(roomId) });
});

module.exports = router;
